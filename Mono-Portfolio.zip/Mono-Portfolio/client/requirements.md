## Packages
framer-motion | For smooth page transitions and element entry animations
react-intersection-observer | To trigger animations when elements scroll into view

## Notes
Strict monochrome color palette requested.
Images should have grayscale filters applied via CSS.
No authentication required for this version.
