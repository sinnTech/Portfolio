import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent",
      description: "Thank you for reaching out. I'll get back to you soon.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      <main className="flex-1 pt-32 pb-24 px-6">
        <div className="max-w-screen-2xl mx-auto grid lg:grid-cols-2 gap-24">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-7xl md:text-[10rem] font-black tracking-tighter uppercase leading-none mb-12">
              Say<br/>Hello
            </h1>
            
            <div className="space-y-12 text-lg md:text-xl font-light">
              <p>
                Interested in working together? Fill out the form or send an email directly. 
                I'm currently accepting new projects for Q4 2024.
              </p>
              
              <div>
                <h3 className="font-bold uppercase tracking-widest text-sm mb-2">Location</h3>
                <p className="text-muted-foreground">Based in San Francisco, CA<br/>Available Worldwide</p>
              </div>

              <div>
                <h3 className="font-bold uppercase tracking-widest text-sm mb-2">Contact Info</h3>
                <p className="text-muted-foreground">hello@portfolio.dev<br/>+1 (555) 000-0000</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <form onSubmit={handleSubmit} className="space-y-8 bg-secondary/30 p-8 md:p-12 border border-border">
              <div className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest">Name</label>
                <Input required placeholder="John Doe" className="h-14 bg-background rounded-none border-0 border-b-2 border-border focus-visible:ring-0 focus-visible:border-black px-0" />
              </div>
              
              <div className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest">Email</label>
                <Input required type="email" placeholder="john@example.com" className="h-14 bg-background rounded-none border-0 border-b-2 border-border focus-visible:ring-0 focus-visible:border-black px-0" />
              </div>

              <div className="space-y-4">
                <label className="text-sm font-bold uppercase tracking-widest">Message</label>
                <Textarea required placeholder="Tell me about your project..." className="min-h-[150px] bg-background rounded-none border-0 border-b-2 border-border focus-visible:ring-0 focus-visible:border-black px-0 resize-none" />
              </div>

              <Button type="submit" className="w-full h-16 bg-black text-white rounded-none uppercase tracking-widest font-bold text-lg hover:bg-black/80 transition-all">
                Send Message
              </Button>
            </form>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
