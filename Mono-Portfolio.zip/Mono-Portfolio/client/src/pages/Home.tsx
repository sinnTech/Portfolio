import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { ContactSection } from "@/components/ContactSection";
import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <main className="flex-1 pt-20">
        <section className="min-h-[90vh] flex flex-col justify-center px-6 relative overflow-hidden">
          <div className="absolute inset-0 grid-pattern opacity-30 pointer-events-none" />
          
          <div className="max-w-screen-2xl mx-auto w-full relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 100 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <h1 className="text-[12vw] leading-[0.85] font-black tracking-tighter mix-blend-difference text-black">
                CREATIVE
                <br />
                DEVELOPER
              </h1>
            </motion.div>

            <div className="mt-12 md:mt-24 flex flex-col md:flex-row justify-between items-start md:items-end gap-8 border-t border-black pt-8">
              <motion.div 
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="max-w-xl"
              >
                <p className="text-xl md:text-2xl font-light leading-relaxed">
                  I craft minimalist digital experiences with clean code and purposeful design. 
                  Specializing in React, TypeScript, and interactive web applications.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6, duration: 0.8 }}
              >
                <Link href="/gallery">
                  <button className="h-16 px-12 bg-black text-white text-lg font-bold uppercase tracking-widest hover:bg-transparent hover:text-black border-2 border-black transition-all duration-300">
                    View My Work
                  </button>
                </Link>
              </motion.div>
            </div>
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce"
          >
            <ArrowDown className="w-6 h-6" />
          </motion.div>
        </section>

        {/* Selected Work Preview */}
        <section className="py-32 bg-black text-white px-6">
          <div className="max-w-screen-2xl mx-auto">
            <div className="flex justify-between items-end mb-24">
              <h2 className="text-6xl md:text-8xl font-bold tracking-tighter">SELECTED<br/>WORKS</h2>
              <Link href="/gallery" className="hidden md:block text-xl border-b border-white pb-2 hover:opacity-70 transition-opacity">
                See All Projects
              </Link>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              {/* Static showcase for landing page aesthetics */}
              <div className="group cursor-pointer">
                <div className="aspect-[4/3] bg-neutral-900 overflow-hidden mb-6 relative">
                   {/* Unsplash abstract architecture */}
                  <img 
                    src="https://images.unsplash.com/photo-1486718448742-163732cd1544?w=800&q=80" 
                    alt="Architecture" 
                    className="w-full h-full object-cover grayscale transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <h3 className="text-3xl font-bold mb-2">System Architecture</h3>
                <p className="text-neutral-400">Backend Infrastructure • 2024</p>
              </div>

              <div className="group cursor-pointer md:mt-32">
                <div className="aspect-[4/3] bg-neutral-900 overflow-hidden mb-6 relative">
                  {/* Unsplash minimalist desk */}
                  <img 
                    src="https://pixabay.com/get/g1882a91d5afdae5f7d926b838ec1a9a0f7b5bee06b18a80ccb03710b0d1e9dfaf3dce8c6bf0132c74afc024705e1ad559b305a0b6f6cd6dcd544edb9d3071bd7_1280.jpg" 
                    alt="Workplace" 
                    className="w-full h-full object-cover grayscale transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <h3 className="text-3xl font-bold mb-2">Productivity Suite</h3>
                <p className="text-neutral-400">Web Application • 2023</p>
              </div>
            </div>
          </div>
        </section>

        {/* Philosophy Section */}
        <section className="py-32 px-6">
          <div className="max-w-screen-2xl mx-auto grid md:grid-cols-2 gap-16">
            <h2 className="text-4xl font-bold uppercase tracking-tighter">My Philosophy</h2>
            <div className="space-y-8 text-xl font-light leading-relaxed">
              <p>
                I believe that good design is as little design as possible. In a world of digital noise, 
                clarity and precision stand out. My work strips away the non-essential to reveal 
                the core function and beauty of digital products.
              </p>
              <p>
                Every line of code and every pixel is placed with intention. I don't just build websites; 
                I create digital environments that respect the user's time and attention.
              </p>
            </div>
          </div>
        </section>

        <ContactSection />
      </main>

      <Footer />
    </div>
  );
}
