import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { ProjectCard } from "@/components/ProjectCard";
import { AddProjectDialog } from "@/components/AddProjectDialog";
import { useProjects } from "@/hooks/use-projects";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Gallery() {
  const { data: projects, isLoading, error } = useProjects();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      <main className="flex-1 pt-32 pb-24 px-6">
        <div className="max-w-screen-2xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-6xl md:text-9xl font-black tracking-tighter uppercase mb-6">
                Project<br/>Archive
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl font-light">
                A collection of experiments, products, and solutions built with code.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <AddProjectDialog />
            </motion.div>
          </div>

          {isLoading ? (
            <div className="h-[50vh] flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin" />
            </div>
          ) : error ? (
            <div className="h-[50vh] flex items-center justify-center">
              <p className="text-destructive font-medium">Failed to load projects. Please try again.</p>
            </div>
          ) : projects?.length === 0 ? (
            <div className="h-[40vh] border border-dashed border-border flex flex-col items-center justify-center text-muted-foreground">
              <p className="text-lg uppercase tracking-widest mb-4">No projects yet</p>
              <AddProjectDialog />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects?.map((project, index) => (
                <ProjectCard key={project.id} project={project} index={index} />
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
