import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
  index: number;
}

export function ProjectCard({ project, index }: ProjectCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative block aspect-[4/5] md:aspect-square bg-secondary overflow-hidden border border-border"
    >
      {/* Image */}
      <img
        src={project.imageUrl}
        alt={project.title}
        className="w-full h-full object-cover grayscale-img"
      />

      {/* Overlay Content */}
      <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6 md:p-8">
        <div className="flex justify-end">
          <div className="bg-white text-black p-2 rounded-full transform translate-x-4 -translate-y-4 opacity-0 group-hover:translate-x-0 group-hover:translate-y-0 transition-all duration-500 delay-100">
            <ArrowUpRight className="w-6 h-6" />
          </div>
        </div>

        <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
          <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
          <p className="text-white/80 line-clamp-3 text-sm leading-relaxed">
            {project.description}
          </p>
          
          {project.link && (
            <a 
              href={project.link}
              target="_blank" 
              rel="noopener noreferrer"
              className="mt-4 inline-block text-white border-b border-white pb-1 text-xs uppercase tracking-widest hover:opacity-70"
            >
              View Project
            </a>
          )}
        </div>
      </div>
    </motion.div>
  );
}
