import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export function Navigation() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "About" },
    { href: "/gallery", label: "Gallery" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-screen-2xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold tracking-tighter uppercase hover:opacity-70 transition-opacity">
          DEV.FOLIO
        </Link>

        <div className="flex items-center gap-8">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <div className="relative group cursor-pointer py-2">
                <span className={cn(
                  "text-sm font-medium tracking-widest uppercase transition-colors duration-200",
                  location === link.href ? "text-primary" : "text-muted-foreground group-hover:text-primary"
                )}>
                  {link.label}
                </span>
                {location === link.href && (
                  <motion.div 
                    layoutId="underline"
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-black"
                  />
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
