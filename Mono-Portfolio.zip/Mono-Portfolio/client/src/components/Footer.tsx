import { Github, Twitter, Linkedin, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="w-full py-12 px-6 border-t border-border bg-background mt-auto">
      <div className="max-w-screen-2xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-sm text-muted-foreground uppercase tracking-wider">
          © {new Date().getFullYear()} Developer Portfolio. All rights reserved.
        </div>
        
        <div className="flex items-center gap-6">
          <a href="#" className="p-2 hover:bg-secondary rounded-full transition-colors group">
            <Github className="w-5 h-5 text-foreground group-hover:scale-110 transition-transform" />
          </a>
          <a href="#" className="p-2 hover:bg-secondary rounded-full transition-colors group">
            <Twitter className="w-5 h-5 text-foreground group-hover:scale-110 transition-transform" />
          </a>
          <a href="#" className="p-2 hover:bg-secondary rounded-full transition-colors group">
            <Linkedin className="w-5 h-5 text-foreground group-hover:scale-110 transition-transform" />
          </a>
          <a href="#" className="p-2 hover:bg-secondary rounded-full transition-colors group">
            <Mail className="w-5 h-5 text-foreground group-hover:scale-110 transition-transform" />
          </a>
        </div>
      </div>
    </footer>
  );
}
