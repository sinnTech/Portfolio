import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

export function ContactSection() {
  return (
    <section className="py-32 px-6 border-t border-border">
      <div className="max-w-screen-2xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-6xl md:text-8xl font-black tracking-tighter mb-8"
            >
              LET'S<br/>WORK<br/>TOGETHER
            </motion.h2>
          </div>

          <div className="space-y-8">
            <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed">
              I'm currently available for freelance projects and open to full-time opportunities. 
              If you have a project that needs some creative injection, let's chat.
            </p>
            
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group flex items-center gap-4 text-2xl font-bold uppercase tracking-wider"
            >
              <span className="border-b-2 border-black pb-2 group-hover:pb-1 transition-all">
                Start a conversation
              </span>
              <ArrowRight className="w-8 h-8 group-hover:translate-x-2 transition-transform" />
            </motion.button>

            <div className="pt-12 grid grid-cols-2 gap-8">
              <div>
                <h4 className="text-sm text-muted-foreground uppercase tracking-widest mb-2">Email</h4>
                <a href="mailto:hello@example.com" className="text-lg font-medium hover:underline">hello@example.com</a>
              </div>
              <div>
                <h4 className="text-sm text-muted-foreground uppercase tracking-widest mb-2">Socials</h4>
                <div className="flex gap-4">
                  <a href="#" className="text-lg font-medium hover:underline">Twitter</a>
                  <a href="#" className="text-lg font-medium hover:underline">LinkedIn</a>
                  <a href="#" className="text-lg font-medium hover:underline">Instagram</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
