import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProjectSchema } from "@shared/schema";
import { useCreateProject } from "@/hooks/use-projects";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Plus } from "lucide-react";
import { z } from "zod";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

type FormValues = z.infer<typeof insertProjectSchema>;

export function AddProjectDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const createProject = useCreateProject();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(insertProjectSchema),
    defaultValues: {
      title: "",
      description: "",
      imageUrl: "",
      link: "",
    },
  });

  function onSubmit(data: FormValues) {
    createProject.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Project Added",
          description: "Your project has been successfully added to the gallery.",
        });
        setOpen(false);
        form.reset();
      },
      onError: (error) => {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 uppercase tracking-widest text-xs h-12 px-6 border-2 border-black hover:bg-black hover:text-white transition-all">
          <Plus className="w-4 h-4" /> Add Project
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] border-2 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold uppercase tracking-tighter">New Project</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase text-xs font-bold tracking-widest">Title</FormLabel>
                  <FormControl>
                    <Input {...field} className="rounded-none border-black focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:border-black/50 bg-secondary/50" placeholder="Project Name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase text-xs font-bold tracking-widest">Image URL</FormLabel>
                  <FormControl>
                    <Input {...field} className="rounded-none border-black focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:border-black/50 bg-secondary/50" placeholder="https://..." />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="link"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase text-xs font-bold tracking-widest">Project Link</FormLabel>
                  <FormControl>
                    {/* JSON types vs HTML inputs: value needs to be string, but schema allows null. Handle empty string as null/undefined if needed, or schema handles empty string. */}
                    <Input {...field} value={field.value || ''} className="rounded-none border-black focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:border-black/50 bg-secondary/50" placeholder="https://..." />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase text-xs font-bold tracking-widest">Description</FormLabel>
                  <FormControl>
                    <Textarea {...field} className="rounded-none border-black focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:border-black/50 bg-secondary/50 min-h-[120px]" placeholder="Brief description of the project..." />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full h-12 rounded-none bg-black text-white hover:bg-black/80 uppercase tracking-widest text-xs font-bold"
              disabled={createProject.isPending}
            >
              {createProject.isPending ? "Creating..." : "Create Project"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
