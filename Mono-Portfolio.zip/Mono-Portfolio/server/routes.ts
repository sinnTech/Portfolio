import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.get(api.projects.get.path, async (req, res) => {
    const project = await storage.getProject(Number(req.params.id));
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    res.json(project);
  });

  app.post(api.projects.create.path, async (req, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      const project = await storage.createProject(input);
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed data
  const existingProjects = await storage.getProjects();
  if (existingProjects.length === 0) {
    console.log("Seeding database with initial projects...");
    await storage.createProject({
      title: "Neural Network Visualization",
      description: "An interactive 3D visualization of a neural network learning process using WebGL and React Three Fiber. Displays real-time weight adjustments and activation patterns.",
      imageUrl: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?q=80&w=2070&auto=format&fit=crop",
      link: "#"
    });
    await storage.createProject({
      title: "Distributed System Monitor",
      description: "A high-performance dashboard for monitoring microservices architecture. Features real-time metrics, log aggregation, and anomaly detection alerts.",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
      link: "#"
    });
    await storage.createProject({
      title: "Minimalist Code Editor",
      description: "A distraction-free code editor built for focus. Supports multiple languages with custom syntax highlighting and vim mode integration.",
      imageUrl: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=2070&auto=format&fit=crop",
      link: "#"
    });
    await storage.createProject({
      title: "Algorithmic Trading Bot",
      description: "Automated crypto trading bot implementing mean reversion and momentum strategies. written in Rust for low-latency execution.",
      imageUrl: "https://images.unsplash.com/photo-1611974765270-ca12586343bb?q=80&w=2070&auto=format&fit=crop",
      link: "#"
    });
  }

  return httpServer;
}
